# Data-only importable Odoo module.
