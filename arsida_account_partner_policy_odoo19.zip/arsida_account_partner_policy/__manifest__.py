{
    'name': 'ARSIDA Account Partner Policy',
    'version': '19.0.1.4.0',
    'summary': 'Optional, required or forbidden partner per accounting account',
    'author': 'ARSIDA',
    'website': 'https://www.linkedin.com/in/arsalansangini/',
    'images': ['static/description/banner.png'],
    'category': 'Accounting',
    'license': 'AGPL-3',
    'depends': ['account', 'base_automation'],
    'data': ['data/partner_policy_fields.xml', 'views/partner_policy_views.xml', 'data/bank_cash_finalize.xml', 'data/partner_policy_automation.xml', 'data/bank_cash_pilot.xml'],
    'installable': True,
    'application': False,
}
