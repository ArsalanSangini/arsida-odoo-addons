# Restrict Journal for Users — Odoo 20 Importable adaptation

Odoo 20 port: uses `ir.access` restrictions with `operation=crud` instead of `ir.rule`. No additional access permissions are granted.

Inspired by `account_restrict_journal` by Cybrosys Techno Solutions (LGPL-3).

This data-only adaptation preserves the per-user deny-list workflow. It does not copy Python overrides or reproduce the original's opposing group rule domains. It restricts journal documents and lines at the record-rule level, including bank and cash statements. Restricted entries are hidden rather than listed with a form-open error. The group enables the policy; removing the group deactivates it without losing the configured list. Existing standard ACL and company rules remain in force.

## Configuration
Import the ZIP in developer mode. As a Settings administrator, open the user and select the forbidden journals under Restricted Journal. Add the user to the Restrict Journals group using the groups screen. Do not assign this group to the administrator used for configuration. Test with a separate user, including journal selection, invoice and payment creation, existing entries, bank matching, reports and multi-company access. Test again after changing the deny-list and removing the group. The module is not runtime-tested in an Odoo database.
