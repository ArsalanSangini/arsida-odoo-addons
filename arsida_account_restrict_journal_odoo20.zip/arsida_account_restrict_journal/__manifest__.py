{
    'name': 'Restrict Journal for Users (Importable)',
    'version': '20.0.1.0.0',
    'category': 'Accounting',
    'summary': 'Restrict accounting journals per user',
    'author': 'Cybrosys Techno Solutions; ARSIDA (importable adaptation)',
    'website': 'https://www.linkedin.com/in/arsalansangini/',
    'images': ['static/description/banner.png'],
    'license': 'LGPL-3',
    'depends': ['base', 'account'],
    'data': ['security/groups.xml', 'data/fields.xml', 'security/rules.xml', 'views/users.xml'],
    'installable': True,
    'application': False,
}
