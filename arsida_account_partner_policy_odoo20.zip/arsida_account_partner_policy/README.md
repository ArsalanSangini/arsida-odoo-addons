# ARSIDA Account Partner Policy — Odoo 20

Importable adaptation of the Odoo 19 module, preserving technical names and XML IDs. Policies: optional, always, never. Bank/cash and payment finalization is experimental; test creation, edit, reconciliation, undo reconciliation and posting on an isolated Odoo 20 test database. Do not deploy to production until those tests pass. No historical bulk update is performed on installation.
